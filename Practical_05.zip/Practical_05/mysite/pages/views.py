from django.http import HttpResponse

def index(request):
    return HttpResponse("<h1>Головна сторінка Django</h1><p>Ласкаво просимо!</p><ul><li>1</li><li>2</li><li>3</li></ul>")

def about(request):
    return HttpResponse("<h1>Про проєкт</h1><p>Практична робота №5. Студент: Ольга Тернова</p>")

def contact(request):
    name = request.GET.get('name')
    if name:
        return HttpResponse(f"<h1>Привіт, {name}!</h1>")
    return HttpResponse("<h1>Контакти</h1><p>Параметр name не передано.</p>")
