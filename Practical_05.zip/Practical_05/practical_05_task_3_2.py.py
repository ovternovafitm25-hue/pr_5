"""Порівняльний аналіз структури Django та Flask проектів."""

import os


def scan_directory(path: str, prefix: str = '') -> list[str]:
    """Рекурсивно сканує каталог та повертає дерево файлів."""
    tree = []
    ignored = {'__pycache__', 'venv', 'venv2', 'db.sqlite3', '.git'}
    try:
        entries = sorted(os.listdir(path))
    except FileNotFoundError:
        return [f"{prefix} [Каталог не знайдено]"]

    entries = [e for e in entries if e not in ignored and not e.endswith('.pyc')]
    for i, entry in enumerate(entries):
        full_path = os.path.join(path, entry)
        is_last = (i == len(entries) - 1)
        connector = '└── ' if is_last else '├── '
        if os.path.isdir(full_path):
            tree.append(f"{prefix}{connector}{entry}/")
            extension = '    ' if is_last else '│   '
            tree.extend(scan_directory(full_path, prefix + extension))
        else:
            tree.append(f"{prefix}{connector}{entry}")
    return tree


def analyze_project(path: str) -> dict:
    """Аналізує проєкт та збирає статистику."""
    stats = {
        'py_files': 0,
        'html_files': 0,
        'css_files': 0,
        'total_size': 0,
        'directories': [],
    }
    ignored = {'__pycache__', 'venv', 'venv2', 'db.sqlite3', '.git'}
    for root, dirs, files in os.walk(path):
        dirs[:] = [d for d in dirs if d not in ignored]
        rel_path = os.path.relpath(root, path)
        if rel_path != '.':
            stats['directories'].append(rel_path)
        for file in files:
            if file.endswith('.pyc'):
                continue
            full_path = os.path.join(root, file)
            try:
                stats['total_size'] += os.path.getsize(full_path)
            except OSError:
                pass
            if file.endswith('.py'):
                stats['py_files'] += 1
            elif file.endswith('.html'):
                stats['html_files'] += 1
            elif file.endswith('.css'):
                stats['css_files'] += 1
    return stats


def compare_projects(django_path: str, flask_path: str):
    """Порівнює два проекти та виводить таблицю відмінностей."""
    print("=" * 60)
    print("ПОРІВНЯННЯ СТРУКТУРИ ПРОЕКТІВ")
    print("=" * 60)

    print(f"\n--- Django ({django_path}) ---")
    for line in scan_directory(django_path):
        print(line)
    django_stats = analyze_project(django_path)

    print(f"\n--- Flask ({flask_path}) ---")
    for line in scan_directory(flask_path):
        print(line)
    flask_stats = analyze_project(flask_path)

    print("\n" + "=" * 60)
    print("ПОРІВНЯЛЬНА ТАБЛИЦЯ")
    print("=" * 60)
    print(f"| {'Характеристика':<22} | {'Django':<10} | {'Flask':<10} |")
    print(f"|------------------------|------------|------------|")
    print(f"| Файли .py              | {django_stats['py_files']:<10} | {flask_stats['py_files']:<10} |")
    print(f"| Файли .html            | {django_stats['html_files']:<10} | {flask_stats['html_files']:<10} |")
    print(f"| Файли .css             | {django_stats['css_files']:<10} | {flask_stats['css_files']:<10} |")
    print(f"| Кількість каталогів    | {len(django_stats['directories']):<10} | {len(flask_stats['directories']):<10} |")
    print(f"| Розмір (байт)          | {django_stats['total_size']:<10} | {flask_stats['total_size']:<10} |")
    print("=" * 60)


def main():
    django_path = 'mysite'
    flask_path = 'myflaskapp'
    for path in [django_path, flask_path]:
        if not os.path.isdir(path):
            print(f"Каталог '{path}' не знайдено.")
            return
    compare_projects(django_path, flask_path)


if __name__ == "__main__":
    main()
