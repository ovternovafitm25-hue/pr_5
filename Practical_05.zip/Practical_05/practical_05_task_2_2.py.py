"""Аналізатор конфігурації Django-проекту."""

import os
import sys
import re


def analyze_settings(settings_path: str) -> dict:
    """Аналізує файл settings.py та повертає ключові параметри."""
    config = {
        'DEBUG': None,
        'INSTALLED_APPS': [],
        'DATABASES': 'Не визначено',
        'LANGUAGE_CODE': None,
        'TIME_ZONE': None,
    }
    if not os.path.exists(settings_path):
        return config

    with open(settings_path, 'r', encoding='utf-8') as f:
        content = f.read()

    debug_match = re.search(r'DEBUG\s*=\s*(True|False)', content)
    if debug_match:
        config['DEBUG'] = debug_match.group(1) == 'True'

    lang_match = re.search(r"LANGUAGE_CODE\s*=\s*['\"]([^'\"]+)['\"]", content)
    if lang_match:
        config['LANGUAGE_CODE'] = lang_match.group(1)

    tz_match = re.search(r"TIME_ZONE\s*=\s*['\"]([^'\"]+)['\"]", content)
    if tz_match:
        config['TIME_ZONE'] = tz_match.group(1)

    apps_match = re.search(r'INSTALLED_APPS\s*=\s*\[(.*?)\]', content, re.DOTALL)
    if apps_match:
        apps_text = apps_match.group(1)
        config['INSTALLED_APPS'] = [app.strip(" '\"") for app in re.findall(r"['\"]([^'\"]+)['\"]", apps_text)]

    if 'sqlite3' in content:
        config['DATABASES'] = 'sqlite3'

    return config


def check_security(settings_path: str) -> list[str]:
    """Перевіряє базову безпеку конфігурації."""
    warnings = []
    if not os.path.exists(settings_path):
        return warnings

    with open(settings_path, 'r', encoding='utf-8') as f:
        content = f.read()

    if re.search(r'DEBUG\s*=\s*True', content):
        warnings.append("DEBUG set to True (небезпечно для production)")

    if re.search(r"SECRET_KEY\s*=\s*['\"][^'\"]+['\"]", content) and 'os.environ' not in content:
        warnings.append("SECRET_KEY захардкоджений у файлі settings.py замість os.environ")

    if re.search(r'ALLOWED_HOSTS\s*=\s*\[\s*\]', content):
        warnings.append("ALLOWED_HOSTS порожній")

    return warnings


def main():
    settings_path = 'mysite/mysite/settings.py'
    if not os.path.exists(settings_path):
        print(f"Файл {settings_path} не знайдено")
        sys.exit(1)

    config = analyze_settings(settings_path)
    print("=== Аналіз конфігурації Django ===\n")
    for key, value in config.items():
        print(f"  {key}: {value}")

    print("\n=== Перевірка безпеки ===\n")
    warnings = check_security(settings_path)
    if warnings:
        for w in warnings:
            print(f"  ⚠ {w}")
    else:
        print("  Попереджень не знайдено")


if __name__ == "__main__":
    main()
