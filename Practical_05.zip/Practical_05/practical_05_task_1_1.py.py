"""Скрипт перевірки середовища розробки."""

import sys
import importlib


def check_python_version():
    """Перевіряє версію Python (потрібна >= 3.10)."""
    version = sys.version_info
    print(f"Python {version.major}.{version.minor}.{version.micro}")
    if version < (3, 10):
        print("  ⚠ ПОПЕРЕДЖЕННЯ: Потрібна версія Python >= 3.10!")
    else:
        print("  Версія Python відповідає вимогам ✓")


def check_package(package_name: str) -> bool:
    """Перевіряє, чи встановлено пакет, і виводить його версію.

    Args:
        package_name: назва пакета для перевірки.

    Returns:
        True, якщо пакет встановлено.
    """
    try:
        module = importlib.import_module(package_name)
        version = getattr(module, '__version__', 'невідома')
        print(f"  {package_name}: {version} ✓")
        return True
    except ImportError:
        print(f"  {package_name}: НЕ ВСТАНОВЛЕНО ✗")
        return False


def main():
    check_python_version()

    print("\nВстановлені пакети:")
    packages = ['django', 'flask']
    results = {pkg: check_package(pkg) for pkg in packages}

    installed_count = sum(1 for v in results.values() if v)
    missing_count = len(results) - installed_count
    
    print(f"\nПідсумок: встановлено пакетів: {installed_count}, відсутні: {missing_count}")
    if missing_count > 0:
        missing_pkgs = [pkg for pkg, installed in results.items() if not installed]
        print(f"Рекомендована команда для встановлення: pip install {' '.join(missing_pkgs)}")


if __name__ == "__main__":
    main()
