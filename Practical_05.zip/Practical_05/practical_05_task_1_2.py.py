"""Генератор requirements.txt з перевіркою залежностей."""

import subprocess
import sys
import json
import os


def get_installed_packages() -> list[dict]:
    """Повертає список встановлених пакетів з версіями.

    Returns:
        Список словників {'name': ..., 'version': ...}.
    """
    result = subprocess.run(
        [sys.executable, '-m', 'pip', 'list', '--format=json'],
        capture_output=True, text=True
    )
    try:
        packages = json.loads(result.stdout)
        return [{'name': pkg['name'], 'version': pkg['version']} for pkg in packages]
    except Exception:
        return []


def generate_requirements(packages: list[dict], filename: str = 'requirements.txt'):
    """Записує пакети у файл requirements.txt.

    Args:
        packages: список словників з ключами 'name' та 'version'.
        filename: ім'я файлу для запису.
    """
    excluded = {'pip', 'setuptools', 'wheel'}
    filtered = [p for p in packages if p['name'].lower() not in excluded]
    
    with open(filename, 'w', encoding='utf-8') as f:
        for p in filtered:
            f.write(f"{p['name']}=={p['version']}\n")


def verify_requirements(filename: str = 'requirements.txt') -> bool:
    """Перевіряє, чи всі пакети з requirements.txt встановлені.

    Args:
        filename: шлях до файлу requirements.txt.

    Returns:
        True, якщо всі залежності задоволені.
    """
    if not os.path.exists(filename):
        print(f"Файл {filename} не знайдено.")
        return False

    installed = {p['name'].lower(): p['version'] for p in get_installed_packages()}
    with open(filename, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or '==' not in line:
                continue
            name, version = line.split('==', 1)
            if name.lower() not in installed:
                return False
    return True


def main():
    packages = get_installed_packages()
    print(f"Знайдено {len(packages)} встановлених пакетів\n")

    for pkg in packages[:10]:
        print(f"  {pkg['name']}=={pkg['version']}")
    if len(packages) > 10:
        print(f"  ... та ще {len(packages) - 10}")

    generate_requirements(packages)
    print(f"\nФайл requirements.txt створено")

    ok = verify_requirements()
    print(f"Перевірка залежностей: {'✓ Усе OK' if ok else '✗ Є розбіжності'}")


if __name__ == "__main__":
    main()
